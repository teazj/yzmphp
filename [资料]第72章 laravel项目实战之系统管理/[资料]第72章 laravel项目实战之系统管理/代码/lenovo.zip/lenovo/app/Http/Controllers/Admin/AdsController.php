<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;

// 使用类

use App\Http\Controllers\Controller;

// 后台广告控制器
class AdsController extends Controller
{
    // 广告首页

    public function index(Request $request){


        
    	// 加载页面

    	return view("admin.sys.ads.index");

    }

}
