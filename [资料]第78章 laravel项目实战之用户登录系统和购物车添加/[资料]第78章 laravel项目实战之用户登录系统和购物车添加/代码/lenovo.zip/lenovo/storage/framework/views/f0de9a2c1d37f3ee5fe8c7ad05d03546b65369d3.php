<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	<a href="http://www.lianxiang.com/savePass/<?php echo e($id); ?>/<?php echo e($token); ?>">找回密码</a>
</body>
</html>