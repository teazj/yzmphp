<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	<a href="http://www.lianxiang.com/jihuo/<?php echo e($id); ?>/<?php echo e($token); ?>">立即激活</a>
</body>
</html>