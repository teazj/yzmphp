<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	<a href="http://www.lianxiang.com/savePass/{{$id}}/{{$token}}">找回密码</a>
</body>
</html>