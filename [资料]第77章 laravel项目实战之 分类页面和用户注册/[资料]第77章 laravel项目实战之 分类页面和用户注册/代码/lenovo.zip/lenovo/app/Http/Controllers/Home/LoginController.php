<?php

namespace App\Http\Controllers\Home;

use Illuminate\Http\Request;

// 使用类

use App\Http\Controllers\Controller;

// 登录控制器
class LoginController extends Controller
{
    // 登录页

    public function index(){

    }
}
