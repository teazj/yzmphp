<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>

    <!-- 搜索框 -->
    <center>
        <form action="/" method="post">
            <?php echo e(csrf_field()); ?>

            <input type="text" name="search" id="">
            <input type="submit" value="搜索">
        </form>
    </center>
    <table border="1" width="800px" align="center">
        <th>ID</th>
        <th>name</th>
        <th>PASS</th>
        <th>statu</th>
        <th>time</th>

        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <tr>
            <td><?php echo e($value->id); ?></td>
            <td><?php echo e($value->name); ?></td>
            <td><?php echo e($value->pass); ?></td>
            <td><?php echo e($value->statu); ?></td>
            <td><?php echo e($value->time); ?></td>
        </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    </table>
</body>
</html>