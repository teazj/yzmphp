$(function(){
	$("#close").click(function(){
		$('#imgs').hide();
	});
})