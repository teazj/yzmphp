<?php 

return array (
  'title' => '111111',
  'keywords' => '2222222',
  'description' => '3333333333',
  'baidu' => '6666666666666',
  'logo' => '149917629116556.jpg',
) ?>