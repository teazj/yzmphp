<tr>
	<th><input type="checkbox" name="" id=""></th>
	<th>ID</th>
	<th>TITLE</th>
	<th>SORT</th>
	<th>IMG</th>
	<th>操作</th>
</tr>

<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
<tr id="tr<?php echo e($value->id); ?>">
	<td><input type="checkbox" value="<?php echo e($value->id); ?>" name="" class="inputs" id=""></td>
	<td><?php echo e($value->id); ?></td>
	<td><?php echo e($value->title); ?></td>
	<td><input type="text" onchange="change(this,<?php echo e($value->id); ?>)" value="<?php echo e($value->sort); ?>" name="" id=""></td>
	<td><img width="200px" src="/Uploads/Goods/<?php echo e($value->img); ?>" alt=""></td>
	<td><a href="/admin/pic/<?php echo e($value->id); ?>/edit" class="glyphicon glyphicon-pencil"></a>&nbsp;&nbsp;&nbsp;<a href="javascript:;" onclick="del(this,<?php echo e($value->id); ?>)" class="glyphicon glyphicon-trash"></a></td>
</tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>