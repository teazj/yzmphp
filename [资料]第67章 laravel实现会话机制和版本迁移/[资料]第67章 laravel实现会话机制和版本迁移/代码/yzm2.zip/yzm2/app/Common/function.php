<?php 

function speak1(){

	echo "云知梦 暑期优惠在即 ！！！！！！！！！！！";
}



 ?>