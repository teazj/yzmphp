@extends('muban.admin')

@section('main')
<!-- 内容 -->
<div class="col-md-10">
	
	<div class="jumbotron">
	 	<img src="/admins/img/4.jpg"height="310px" width="100%" alt="">
	 	<h2>联想 后台管理系统</h2>
	 	<p>开发者 ： 赵丰泰</p>
	</div>
</div>

@endsection