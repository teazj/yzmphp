<!-- 页脚-->
  <div class=" bottom">
    <!-- top -->
    <div class="container bottom-1"><img src="/style/home/img/6.png" alt=""></div>
    <!-- middle -->
    <div class=" bottom-2">
            <dl>
                <dt> <a>购物指南 </a></dt>
                <dd>
                  <a target="_blank" href="">服务商信息</a>
                  <a target="_blank" href="">购买流程</a> 
                  <a target="_blank" href="">注册登录</a>
                </dd>
            </dl>
            <dl>
                <dt> <a>配送方式</a></dt>
                <dd> 
                  <a target="_blank" href="">配送方式</a> 
                  <a target="_blank" href="">配送方式信息</a> 
                  <a target="_blank" href="">签收原则</a>
                  <a target="_blank" href="">物流查询</a>
                </dd>
            </dl>
            <dl>
                <dt> <a>支付方式  </a></dt>
                <dd> 
                  <a target="_blank" href="">支付方式</a> 
                  <a target="_blank" href="">支付问题</a>
                  <a target="_blank" href="">分期支付</a>
                </dd>
            </dl>
            <dl>
                <dt> <a>订单信息  </a></dt>
                <dd> 
                  <a target="_blank" href="">订单信息</a> 
                  <a target="_blank" href="">其它频道订单发票</a>
                  <a target="_blank" href="">手机频道订单发票</a>
                </dd>
            </dl>
            <dl>
                <dt> <a>售后服务 </a></dt>
                <dd> 
                  <a target="_blank" href="">Lenovo频道商品售后</a>
                  <a target="_blank" href="">手机频道商品售后7天</a> 
                  <a target="_blank" href="">无理由退换货说明</a>
                  <a target="_blank" href="">24小时在线客服</a>
                </dd>
            </dl>
            <dl style="padding-right:0;">
                <dt> <a>其他说明  </a></dt>
                <dd> 
                  <a target="_blank" href="">服务承诺</a> 
                  <a target="_blank" href="">账户安全</a> 
                  <a target="_blank" href="">产品安全</a>
                </dd>
            </dl>
    </div>
    <!-- bottom -->
    <div class="container bottom-3">
      <div class='action'>
        <div class="yihang">
              <a href="" title="关于联想" target="_blank">关于联想</a><span class="gang">|</span>
              <a href="" title="联系我们" target="_blank">联系我们</a><span class="gang">|</span>
              <a href="" title="工作机会" target="_blank">工作机会</a><span class="gang">|</span>
              <a href="/About/news_center.aspx" title="新闻中心" target="_blank">新闻中心</a><span style="display:none;">|</span>
              <a href="" style="display:none;" title="商城移动版" target="_blank">商城移动版</a><span class="gang">|</span>
              <a href="" title="聚享汇会员专享" target="_blank">聚享汇会员专享</a><span class="gang">|</span>
              <a href="" title="联想社区" target="_blank">联想社区</a><span class="gang">|</span>
              <a href="" title="NBD" target="_blank">NBD</a><span class="gang">|</span>
              <a href="" title="联想超融合" target="_blank">联想超融合</a><span class="gang">|</span>
              <a href="" title="联想官网热搜榜" target="_blank">联想官网热搜榜</a><span class="gang">|</span>
              <a href="" title="分类大全" target="_blank">分类大全</a><span class="gang">|</span>
              <a href="" title="联想产品大全" target="_blank">联想产品大全</a><span class="gang">|</span>
              <a href="" title="智慧医疗" target="_blank">智慧医疗</a>
        </div>
        <div class="erhang">
              版权所有：1998-2016 联想集团<span class="gang">|</span>
              <a href="" title="法律公告" target="_blank">法律公告</a><span class="gang">|</span>
              <a href="" title="隐私保护" target="_blank">隐私保护</a><span class="gang">|</span>
              <a href="" target="_blank">京ICP备11035381</a><span class="gang">|</span>
              <i style="font-style:normal;">京公网安备110108007970号</i><span class="gang">|</span>
              <a href="http://pic.shop.lenovo.com.cn/g1/M00/01/3C/CmBZD1aLdE-AHmSmAAJk4Nd8ReY449.jpg" title="营业执照" target="_blank">营业执照：110000410127232</a><span class="gang">|</span>
              <a href="/LenovoMap/LenovoMap_Direct.aspx?intcmp=MAP20140730_1" title=" 销售网点" target="_blank">销售网点</a><span class="gang">|</span>
              <a href="http://support1.lenovo.com.cn/lenovo/wsi/station/servicestation/default.aspx?intcmp=MAP20140730_2" title=" 服务网点" target="_blank">服务网点</a>
          </div>
        </div>
      </div>
  </div>
</div> 